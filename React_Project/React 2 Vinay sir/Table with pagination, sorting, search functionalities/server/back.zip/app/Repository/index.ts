import productRepository from "./ProductRepository/productRepository";

export default {
    productRepository
}