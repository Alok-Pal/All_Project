import productController  from "./ProductController/productController";

export default{
    productController
}