export class Responsemodal {
    message: unknown 
    data: any
    status: number | undefined
    error: any
}
