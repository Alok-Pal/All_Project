export interface ProductModal {
    image: string,
    title: string,
    description: string,
   
}

export interface CategoryModal{
    categoryName : string
}