import Server from './server';

const app = new Server()
app.start()