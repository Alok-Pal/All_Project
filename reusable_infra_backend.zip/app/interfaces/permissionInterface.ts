export interface PermissionEdit {
	all: boolean;
	edit: boolean;
	delete: boolean;
	view: boolean;
}
