import UserInfo from './userInterface';
import CompanyInfo from './companyInterface';

export { UserInfo, CompanyInfo };
