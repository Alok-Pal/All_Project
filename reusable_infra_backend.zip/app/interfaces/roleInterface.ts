export interface updateRole {
	roleName: string;
	roleDescription: string;
	roleStatus: boolean;
	roleId: string;
	companyId?: string;
	orgId?: string;
}
