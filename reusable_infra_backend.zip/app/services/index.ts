import authServices from './authServices';
import userServices from './userServices';
import roleService from './roleService';
import permissionService from './permissionService';
export default { authServices, userServices, roleService, permissionService };
