export interface TableActionHeaderProps {
	children?: any;
	title: string;
}
