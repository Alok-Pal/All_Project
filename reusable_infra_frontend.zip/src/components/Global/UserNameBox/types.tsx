export interface UserNameBoxProps {
	imageUrl?: string;
	name: string;
}
