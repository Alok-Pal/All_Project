export type SideDrawerBodyProps = {
	closeDrawerByAnimation: () => void;
	editSelectedRole?: any;
	setEditSelectedRole?: any;
};
