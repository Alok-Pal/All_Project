export type SideDrawerBodyProps = {
	closeDrawerByAnimation: () => void;
	setEditSelectedUser: any;
	editSelectedUser: any;
};
