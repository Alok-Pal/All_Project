export interface SettingsBodyProps {
	selectedSidebar: string;
}
