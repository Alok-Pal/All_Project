import RegisterLayoutBody from './RegisterLayoutBody';

export { RegisterLayoutBody };
