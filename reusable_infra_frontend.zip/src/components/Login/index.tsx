import LoginLayoutBody from './LoginLayoutBody';

export { LoginLayoutBody };
