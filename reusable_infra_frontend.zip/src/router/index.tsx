import router from './BrowserRouter';

export { router };
