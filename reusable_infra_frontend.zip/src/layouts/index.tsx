import RegistrationLayout from "./Register";
import LoginLayout from "./Login";
import SettingsLayout from "./Settings";
import GlobalLayout from "./Global";

export { RegistrationLayout, LoginLayout, SettingsLayout, GlobalLayout };
