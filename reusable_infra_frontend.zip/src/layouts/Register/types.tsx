export interface RegisterLayoutInterface {
	children?: any;
}
