export interface SettingsLayoutProps {
	children?: any;
	onSideBarChange: (data: any) => void;
	selectedSidebar?: string;
}
