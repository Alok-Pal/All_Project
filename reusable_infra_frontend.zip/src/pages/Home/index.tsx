const Home = () => {
	return <div>Home page</div>;
};

export default Home;
