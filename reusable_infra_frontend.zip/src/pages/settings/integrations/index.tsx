import IntegrationTable from "components/settings/Integration";

export default function Integrations() {
  return (
    <div>
      <IntegrationTable />
    </div>
  );
}
