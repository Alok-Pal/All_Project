import SelectConnectionBody from "components/settings/SelectConnection";

const SelectConnection = () => {
  return <SelectConnectionBody/>;
};
export default SelectConnection;
