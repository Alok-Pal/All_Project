import ConnectionBody from "components/settings/Connection"

const Connection = () => {
  return (
    <ConnectionBody/>
  )
}
export default Connection