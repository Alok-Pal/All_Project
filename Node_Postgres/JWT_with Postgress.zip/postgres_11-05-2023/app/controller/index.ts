import userController from "./userController/userController";
import postController from "./postController/postController";
import profileController from "./profileController/profileController"
import categoryController from "./categoryController/categoryController";


export default {
    userController,postController,profileController,categoryController
}