import userRepo from "./userRepo/userRepo";
import postRepo from "./postRepo/postRepo";
import profileRepo from "./profileRepo/profileRepo"
import categoryRepo from "./categoryRepo/categoryRepo"

export default {
    userRepo,postRepo,categoryRepo ,profileRepo
}