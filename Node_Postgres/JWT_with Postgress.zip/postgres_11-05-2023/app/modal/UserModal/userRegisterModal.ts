export interface UserModal {
    email: string
    name?: string,
    password : string
}