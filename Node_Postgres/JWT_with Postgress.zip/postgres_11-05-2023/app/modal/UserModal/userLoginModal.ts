export interface UserLoginModal {
    id?: number
    email: string,
    password: string,
}