export interface ProfileModal {
    bio?: string
    // userid should be unique
    userId: number
}