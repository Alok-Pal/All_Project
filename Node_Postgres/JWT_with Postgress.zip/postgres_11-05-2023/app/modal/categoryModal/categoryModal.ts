export interface CategoryModal{
  category :string

}