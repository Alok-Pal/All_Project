export class Responsemodal {
    public message : string |undefined
    public data : any
    public status : number |undefined
    public error : any
}