export interface PostModal {
    title: string,
    content?: string
    published?: boolean
    userId: number
}